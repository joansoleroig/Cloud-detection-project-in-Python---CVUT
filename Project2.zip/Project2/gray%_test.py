import numpy as np
import cv2
import glob


## READ ALL IMAGES
cv_img = []
for img in glob.glob("*.jpg"):
    n= cv2.imread(img)
    cv_img.append(n)
    
##DEFINE GRAY/WHITE COLOR RANGES
gray = [210, 210, 210]  # RGB
diff = 40
boundaries = [([gray[2]-diff, gray[1]-diff, gray[0]-diff],
               [gray[2]+diff, gray[1]+diff, gray[0]+diff])]


##IMAGE BY IMAGE GRAY %
n=0
gray_list=[]
for (lower, upper) in boundaries:
    lower = np.array(lower, dtype=np.uint8)
    upper = np.array(upper, dtype=np.uint8)
    for image in cv_img:
        mask = cv2.inRange(image, lower, upper)
        output = cv2.bitwise_and(image, image, mask=mask)
        ratio_gray1 = cv2.countNonZero(mask)/(image.size/3)
        n=n+1
        rounded=np.round(ratio_gray1*100, 2)
        sentence = 'gray pixel percentage of image '
        #print(sentence + str(n) +" is: "+ str(rounded))
        gray_list.append(rounded)
        if n<5:
            message='Stop the machine\n'
            f = open("observations.txt", "a")
            f.write(str(n)+';'+str(rounded)+';'"Not enough data"+';'+message)
            f.close()
        else:
            sublist=gray_list[n-5:n-1]
            mean_last_four=np.round(sum(sublist)/4,2)
            if rounded>15:
                message='Stop the machine\n'
                f = open("observations.txt", "a")
                f.write(str(n)+';'+str(rounded)+';'+str(mean_last_four)+';'+message)
                f.close()
            elif rounded > mean_last_four and rounded > 10:
                message='Stop the machine\n'
                f = open("observations.txt", "a")
                f.write(str(n)+';'+str(rounded)+';'+str(mean_last_four)+';'+message)
                f.close()
            else:
                message='Keep the machine ON\n'
                f = open("observations.txt", "a")
                f.write(str(n)+';'+str(rounded)+';'+str(mean_last_four)+';'+message)
                f.close()            

